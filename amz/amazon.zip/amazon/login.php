<?php
$con=mysqli_connect("localhost","root","","amz");
if ($_SERVER['REQUEST_METHOD'] == "POST") {
if(!$con){die("error!!!");}
$name = $_POST['name'];
$phone = $_POST['no'];
$pass = $_POST['pass'];
if (!empty($name) && (strlen($phone) == 10)) {
    $sql = "INSERT INTO `logdata`(`name`, `phone` ,`pass`) VALUES ('$name','$phone','$pass');";
    $checkQuery = "SELECT COUNT(*) as count FROM `logdata` WHERE `phone` = '$phone'";
    $checkResult = mysqli_query($con, $checkQuery);
    $row = mysqli_fetch_assoc($checkResult);
    $count = $row['count'];
    if ($count == 0) {
        $result = mysqli_query($con, $sql);
        if ($result) {
            echo '<div class="alert alert-warning alert-dismissible fade show nav-alert alert1" role="alert">
            <strong>welldone!</strong> account created succesfully <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div> ';
        } else {
            echo "Error: " . mysqli_error($con);
        }
    } else {
        echo '<div class="alert alert-warning alert-dismissible fade show nav-alert alert1" role="alert">
     Email already exists in the database. Cannot insert duplicate data. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div> ';
    }
}
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        *{    font-family: "Amazon Ember", Arial, sans-serif;}
        .amazon-logo {
            filter: invert(1);
            margin-top: 20px;
    margin-left: 42px;

        }

        .container {
            margin: 2px auto;
            height: 100vh;
            width: 350px;
            display: flex;
            align-items: start;
            justify-content: center;
        }

        .title {
            margin-top: 30px;
            padding: 20px;
            border: 1px solid rgba(90, 88, 88, 0.422);
            border-radius: 10px;
        }

        .flex {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .create {
            margin: 2px;
            font-size: 34px;
            font-family: monospace;
            margin-bottom: 14px;
        }

        .name {
            font-weight: bolder;
            margin: 16px 2px 8px 2px;
        }

        .name1 {
            font-weight: bolder;
            margin: 16px 2px 8px 2px;
        }

        .password {
            font-weight: bold;
            margin: 16px 2px 8px 2px;
        }

        .note {
            font-size: 12px;
            font-weight: 500;
            letter-spacing: 1px;
        }

        button {
            background-color: #ffd814;
            padding: 8px 90px;
            border-radius: 12px;
            border: none;
            font-weight: 400;
        }

        input {
            width: 100%;
            padding: 6px 4px;
            border-radius: 4px;
            border: 1px solid gray;
        }

        select {
            width: 70px;
            padding: 6px 4px;
            border-radius: 4px;
        }

        input[type="number"] {
            width: 209px;
        }
        .bottom{font-size: 14px;}
        a{text-decoration: none;}
    </style>
</head>

<body>
    <div class="container">
        <div class="inner">

            <div>
                <div class="flex"> <img class="amazon-logo" src="img/images/amazon-logo-white.png">.in</div>
                <div class="title">
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <p class="create">Create account</p>
                    <p class="name">Your name</p>
                    <input type="text" name="name" placeholder="Name">
                    <p class="name1">Mobile number</p>
                    <select>
                        <option value="india-91">IN +91</option>
                        <option value="india-91">iceland +354</option>
                        <option value="india-91">australia +61</option>
                    </select>
                    <input type="number" name="no" placeholder="Mobile number">
                    <p class="password">password</p>
                    <input type="password" name="pass" placeholder="At least 6 characters">
                    <p class="note"><br>! Passwords must be at least 6 characters.</p>
                    <p class="bottom">To verify your number, we will send you a text message with a temporary code. Message and datarates may apply</p><br>
                    <button>verfy submit</button>
                    </form>
                    <br>
                    <hr>
                    <p class="bottom"> Already have an account?<a href="sign.php"> Sign in</a></p>
                    <p class="bottom">By creating an account or logging in, you agree to Amazon’s<a href="#"> Conditions of Use</a> and <a href="#">Privacy Policy</a>.</p>
                </div>
            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>