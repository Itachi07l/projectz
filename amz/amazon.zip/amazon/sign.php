<?php
$con=mysqli_connect("localhost","root","","amz");
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $phone = $_POST['phone'];
    if (!empty($phone)) {
        $query = "select * from logdata where phone='$phone'";
        $result = mysqli_query($con, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $u = mysqli_fetch_assoc($result);
                if ($u['phone'] == $phone) {
                    header('location: amazon.html');
                    die;
                }
        }
        echo "<script >alert('invaild info !')</script>";
    } else {
        echo "<script >alert('wrong phone !')</script>";
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        * {
            font-family: "Amazon Ember", Arial, sans-serif;
        }

        .amazon-logo {
            filter: invert(1);
            margin-top: 20px;
            margin-left: 42px;

        }

        .container {
            margin: 2px auto;
            height: 100vh;
            width: 350px;
            display: flex;
            align-items: start;
            justify-content: center;
        }

        .title {
            margin-top: 30px;
            padding: 20px;
            border: 1px solid rgba(90, 88, 88, 0.422);
            border-radius: 10px;
        }

        .flex {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .create {
            margin: 2px;
            font-size: 34px;
            font-family: monospace;
            margin-bottom: 14px;
        }

        .name {
            font-weight: bolder;
            margin: 16px 2px 8px 2px;
        }


        .note {
            font-size: 12px;
            font-weight: 500;
            letter-spacing: 1px;
        }

        button {
            background-color: #ffd814;
            padding: 8px 90px;
            border-radius: 12px;
            border: none;
            font-weight: 400;
            width: 100%;
        }

        input {
            width: 100%;
            padding: 6px 4px;
            border-radius: 4px;
            border: 1px solid gray;
        }

        .bottom {
            font-size: 14px;
        }

        a {
            text-decoration: none;
        }

        .hr {
            width: 120px;
        }

        .f {
            display: flex;
            align-items: center;
        }

        .nowrap {
            width: 121px;
        }

        .b {
            background-color:rgb(255, 249, 249);
            border: 1px solid rgb(149, 146, 146);
            box-shadow: 1px 1px 2px rgb(133, 133, 133);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="inner">

            <div>
                <div class="flex"> <img class="amazon-logo" src="img/images/amazon-logo-white.png">.in</div>
                <div class="title">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <p class="create">Sign in </p>
                    <p class="name">mobile phone number</p>
                    <input type="text" name="phone"><br><br>
                    <button>continue</button></form>
                    <br>
                    <p class="bottom"> By continuing, you agree to Amazon's<a href=""> Conditions of Use</a>and <a
                            href="#">Privacy Notice</a></p>

                    <ul>
                        <li>Need help?</li>
                    </ul>
                    <hr>
                </div><br>
                <div class="f">
                    <hr class="hr"><span class="nowrap">New to Amazon?</span>
                    <hr class="hr">
                </div><br>
                <div><button class="b"><a href="login.php">Create your Amazon account</a></button></div>
            </div>
            
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>