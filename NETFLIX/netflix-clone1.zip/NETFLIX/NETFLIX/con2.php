<?php
session_start();
include("db.php");
?> 
<html>

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital@1&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital@1&family=Ubuntu:wght@500&display=swap"
        rel="stylesheet">

    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: 'Roboto Mono', monospace;
        }

        .container1 {
            background: url("img/bgimg.jpg");
            /* box-shadow:inset 20px 17px 61px 60px black; */
            box-shadow:inset 0 -40px 20em 105px black, 0 0 0 2px white;
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;

        }

        .main {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: white;
            width: 800px;
            height: 420px;
            gap: 35px;
            border-radius: 25px;

        }

        form {
            padding: 24px;
        }

        .title {
            text-align: center;
            margin: 18px 2px;
            text-align: center;
            margin: 18px 2px;
            font-weight: bolder;
            text-transform: capitalize;
            font-family: 'Ubuntu', sans-serif;
        }

        input {
            margin: 10px 2px;
            padding: 9px 20px;
            border-radius: 8px;
            font-size: 18px;
            border: none;
            background-color: rgb(239, 236, 236);
        }

        span {
            flex-direction: column;
            display: flex;
            align-items: center;
        }

        input[type=submit] {
            width: 60%;
            background-color: rgb(187, 9, 9);
            color: white;
            transition: all 2s;

        }

        input[type=submit]:hover {
            background-color: rgb(244, 11, 11);
            box-shadow: 2px 2px 12px black;
            color: white;
            font-size: 19px;
        }

        .sec {
            background: linear-gradient(90deg, rgba(89, 0, 140, 1) 10%, rgba(9, 9, 121, 1) 35%, rgba(19, 2, 70, 1) 100%);
            height: 100%;
            width: 445px;
            border-top-left-radius: 30%;
            border-bottom-left-radius: 30%;
            border-top-right-radius: 25px;
            border-bottom-right-radius: 25px;
            color: white;
            font-family: 'Ubuntu', sans-serif;
            padding: 12px;
            flex-wrap: wrap;
        }

        .sub-sec {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            width: 100%;
            height: 100%;
        }

        .sub-sec>p {
            margin: 30px 2px;
            text-align: center
        }

        .a {
            border: 2px solid white;
            border-radius: 8px;
            padding: 8px 25px;
            color: white;
            text-decoration: none;
            margin: 12px 2px;
            transition: all 2s;
            animation: an 2s linear infinite;
        }

        .a:hover {
            border: 4px solid aqua;
            transform: scale(1.2);
        }
        .alert{
            margin-bottom: 0px;
        }
        .alert1{
            background-color: rgb(82 19 127);
    color: rgb(0, 254, 199);
        }

        @keyframes an {
            50% {
                filter: hue-rotate(350deg);
            }
        }
        input[type=submit]:hover{
            animation: an 2s linear infinite;
        }
    </style>
</head>

<body>
    <?php
    if($_SERVER['REQUEST_METHOD']=="POST"){
        $name=$_POST['name'];
        $username=$_POST['username'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $dob=$_POST['dob'];
    if(!empty($email) && !empty($name) && (strlen($phone)==9)){
        // $sql="INSERT INTO `logdata`(`username`, `email`, `phone`) VALUES ('$name','$email','$phone')";
       $sql="INSERT INTO `logprofile1` ( `name`, `username`, `email`, `phone`, `dob`) VALUES ('$name',  '$username',' $email',' $phone',' $dob');";
        $result=mysqli_query($con,$sql);
        echo '<div class="alert alert-warning alert-dismissible fade show nav-alert alert1" role="alert">
        <strong>welldone!</strong> account created succesfully 
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div> ';
          
    }
    else{ echo '<div class="alert alert-warning alert-dismissible fade show nav-alert alert1" role="alert">
        <strong>ERROR !</strong> plz enter a some vaild infomation 
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';}}
    ?>
    <div class="container1">
        <div class="main">
            <form action="con2.php" method="post">
                <h1 class="title">sign in </h1>
                <input type="text" name="name" placeholder="name"><br>
                <input type="text" name="username" placeholder="username"><br>
                <input type="text" name="email" placeholder="email"><br>
                <input type="text" name="phone" placeholder="phone"><br>
                <input type="text" name="dob" placeholder="dob"><br>
                <span> <input type="submit">
                </span>
            </form>
            <div class="sec">
                <div class="sub-sec">
                    <h2>
                        <pre>welcome to Netflix</pre>
                    </h2>
                    <p>Going back to your Netflix-side to view all movies & anime</p>
                    <a class="a" href="index.php">Go back</a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>