<?php
include("db.php");
include("con1.php");
$e=$_SESSION['email'];
$query1 = "select * from logprofile1  where  `email` =  '$e'";
$result1 = mysqli_query($con, $query1);
// $name = $_POST['name1'];
// $dob = $_POST['dob'];
// $sql1 = "INSERT INTO `logprofile1` ( `name`, `username`, `email`, `phone`, `dob`) VALUES ('$name',  '$username',' $email',' $phone',' $dob');";
// $rec = mysqli_query($con, $sql1);

//  $ul=mysqli_fetch_assoc($result1);
// $ul = mysqli_fetch_array($result1);
// $name2 = $ul['name'];
// $username2 = $ul['username'];
// $email2 = $ul['email'];
// $phone2 = $ul['phone'];
// $dob2 = $ul['dob'];


    $u=mysqli_fetch_assoc($result1);
     $name2 = $u['name'];
     $username2 = $u['username'];
     $email2 = $u['email'];
     $phone2 = $u['phone'];
     $dob2 = $u['dob'];
 
?>
<!DOCTYPE html>
<html>

<head>
    <title>user -profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Kode+Mono:wght@400..700&family=Orbitron:wght@400..900&display=swap" rel="stylesheet">

    <style>
        * {
            padding: 0;
            margin: 0;
            font-family: "Orbitron", sans-serif;

        }

        .main {
            background-image: url(img/bgimg.jpg);
            height: 50vh;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: max(1200px, 100vw);
            position: relative;
            z-index: 1;
        }

        .box {
            height: 50vh;
            width: 100vw;
            opacity: 0.44;
            background-color: rgb(0, 0, 0);
            position: absolute;
            top: 0px;
            z-index: -1;
        }

        .svg {
            position: relative;
            width: 240px;
            z-index: 1;
            margin: 12px;

        }

        .btn {
            border: 1px solid white;
            padding: 4px 14px;
            border-radius: 2px;
            background-color: black;
        }

        .btn-red {
            margin-right: 35px;
            padding: 7px 12px;
            margin-left: 6px;
            background-color: rgb(253, 0, 0);
            border: none;
        }

        .m {
            margin-top: 36px;
        }

        .center {
            font-size: 24px;
            padding: 0px 30px;
            display: flex;
            align-items: start;
            justify-content: start;
            flex-direction: column;
            height: calc(100% - 50px);
            gap: 14px;
            position: relative;
            margin-top: 24px;
        }

        nav {
            display: flex;
            justify-content: space-between;
            z-index: 1;
        }

        input {
            margin-left: 8px;
            background-color: transparent;
            outline: none;
            border: none;
            border-bottom: 2px solid white;
            font-size: 20px;
            font-weight: bolder;
        }

        ::placeholder {
            color: rgb(0, 255, 225);
            opacity: 1;
        }

        .center * {
            color: white;
        }

        .back {
            color: white;
        }
    </style>
</head>

<body>
    <div class="main">
        <div class="box"></div>
        <nav>
            <span class="svg"><img class="svg" src="img/svg.svg"></span>
            <div><button class="btn btn-red m"><a href="index.php" class="back">back</a></button></div>
        </nav>
        <div class="center">
                <div><span class=""><b>FullName:<?php echo " " . $name2 . " "; ?></b></span></div>
                <div><span><b>UserName:<?php echo " " . $username2; ?></b></span></div>
                    <div><span><b>Email:<?php echo " " . $email2 . " "; ?></b></span></div>
                        <div><span><b>Phone:<?php echo " " . $phone2 . " "; ?></b></span></div>
                            <div><span><b>Date of birth:</b></span><span><?php echo " " . $dob2 . " "; ?></span></div>
            <button class="red btn-red"><b><a href="editprofile.php">edit-prfile</a></b></button>
        </div>
 </div>
        <script src="profile.js"></script>
</body>
</html>