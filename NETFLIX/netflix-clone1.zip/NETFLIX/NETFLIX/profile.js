document.querySelector(".btn-event").addEventListener('click', () => {
    var list = document.querySelectorAll(".ip");
    for (var i = 0; i < list.length; i++) {
        if (list[i].style.visibility === "visible") {
        list[i].style.visibility="hidden";}
         else {list[i].style.visibility = "visible";}
    };
 }
)

/* <input class="ip" type="text" name="name1" placeholder="Full name">
<input class="ip" type="text" name="dob" placeholder="Date of birth"> */