<?php
session_start();
include("db.php");
if($_SERVER['REQUEST_METHOD']=="POST"){
    $email=$_POST['email'];
    $_SESSION['email'] = $email; 
    if(!empty($email)){
     $query="select * from logdata where email='$email' limit 1";
     $result=mysqli_query($con,$query);
     if($result){
         if($result && mysqli_num_rows($result)>0){
            $u=mysqli_fetch_assoc($result);
            if($u['email']==$email){
                header('location: movies.html');
                die;
            }
         }
     }
     echo "<script >alert('wrong email !')</script>";
    }
       else{
        echo "<script >alert('wrong email !')</script>";

       }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <style>

::-webkit-scrollbar {
            height: 6px;
            width: 4px;
            background-color: white;
            border: none;
        }
        * {
            color: white;
            padding: 0;
            margin: 0;
            transition: all 1s  linear;
        }

        body {
            background-color: black;
        }

        .main {
            background-image: url(img/bgimg.jpg);
            height: 70vh;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: max(1200px, 100vw);
            position: relative;
        }

        .box {
            height: 70vh;
            width: 100vw;
            opacity: 0.44;
            background-color: rgb(0, 0, 0);
            position: absolute;
            top: 0px;
        }

        nav {
            height: 50px;
            margin: auto;
            max-width: 62vw;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            z-index: 10;
        }

        .svg {
            position: relative;
            width: 140px;
            z-index: 1;
        }

        .btn {
            border: 1px solid white;
            padding: 4px 14px;
            border-radius: 2px;
            background-color: black;
        }

        .btn-red {
            padding: 7px 12px;
            margin-left: 6px;
            background-color: red;
            border: none;
            margin-top: 4px;
        }

        .center {
            padding: 0px 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            height: calc(100% - 50px);
            gap: 14px;
            position: relative;
        }

        .center> :first-child {
            text-align: center;
            font-weight: bolder;
            padding: 2px 2px 8px 1px;
            font-size: 40px;
        }

        .center> :nth-child(2) {
            text-align: center;
            font-size: 38px;
            font-weight: 400;
        }

        .center> :nth-child(3) {
            text-align: center;
            font-size: 17px;
            padding-bottom: 6px;
            font-weight: 400;
        }

        .red {
            padding: 10px 22px;
        }

        .line {
            height: 4px;
            background-color: gray;

        }

        .input {
            display: flex;
        }

        .ip {
           
            padding: 6px 52px 6px 12px;
            color: white;
            border: 1px solid white;
            background-color: #212020;
        }

        .first {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: auto;
            width: 70vw;

        }

        .sec-img img {
            position: relative;
            z-index: 10;
            width: 30vw;
        }

        .sec-img {
            position: relative;
        }

        .sec-img video {
            width: 25vw;
            position: absolute;
            top: 51px;
            right: 0;
        }

        section>div {
            display: flex;
            flex-direction: column;
        }

        .first>div>span:nth-child(1) {
            text-align: center;
            font-size: 28px;
            padding: 30px 3px 4px 2px;
            font-weight: bolder;
        }

        .first>div>span:nth-child(2) {
            font-size: 16px;
            text-align: center;
            font-weight: bolder;
        }

        .thir-img>.video {
            width: 19vw;
            position: absolute;
            top: 24px;
            right: 75px;
        }

        .faq {
            background-color: black;
            color: white;
            padding: 26px;
            text-align: center;
        }

        .faqbox {
            font-size: 25px;
            display: flex;
            background-color: #2d2d2d;
            padding: 25px 58px 24px 28px;
            max-width: 64vw;
            margin: 18px auto;
        }

        .faqlast {
            margin: 12px 2px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .faqlast p {
            margin: 12px;
        }

        .footer {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            width: 60vw;
            margin: auto;
        }

        .items {
            font-size: 20px;
            padding: 24px;
            gap: 20px;
            display: flex;
            flex-direction: column;
        }

        .ques {
            padding-bottom: 50px;
            margin: 50px auto;
            max-width: 60vw;
        }

        @media screen and (max-width:1900px) {
            nav {
                max-width: 80vw;
            }

            .main {
                height: 64vh;
            }
        }

        @media screen and (max-width:960px) {
            .first {
                flex-direction: column;
            }

            .sec-img img {
                width: 70vw;
            }

            .sec-img video {
                width: 57vw;
                position: absolute;
                top: 34px;
                right: 20px;
            }

            .secend {
                flex-direction: column-reverse;
            }

            .thir-img>.video {
                width: 42vw;
                position: absolute;
                top: 24px;
                right: 8vh;
            }

            .faqbox {
                padding: 11px 55px 6px 28px;
            }

        }

        @media screen and ((min-width:1400px) and (max-width:2165px)) {
            .thir-img>.video {
                width: 18vw;
                position: absolute;
                top: 29px;
                right: 10vh;
            }
        }

        @media screen and (max-width:500px) {
            .input {
                flex-direction: column;
                gap: 6px;
                align-items: center;
            }

            nav {
                max-width: 90vw;
            }

            .center> :first-child {
                font-size: 22px;
            }

            .center> :nth-child(2) {
                font-size: 14px
            }

            .center> :nth-child(3) {
                font-size: 14px;
                font-weight: bolder;
            }

            .red {
                margin-top: 16px;
            }

            .footer {
                grid-template-columns: 1fr 1fr;
            }

            .items {
                font-size: 15px;
            }

            .faqbox {
                font-size: 18px;
            }

            .no {
                display: none;
            }
        }

        @media screen and (min-height:1065px) {
            .main {
                background-size: cover;
            }
        }

        @media screen and (width:1366px) and (height: 768px) {
            .main {
                height: 80vh;
            }

            .center {
                height: calc(92% - 0px);
            }

            .box {
                height: 80vh;
            }
        }

        .Contact {
            color: white;
        }

        .none {
            display: none;
        }
        .a{
            color: white;
        }
        .form{    display: contents;}
        .footer1{
           text-align: center;
        }
    </style>
</head>

<body>
    <div class="main">
        <div class="box"></div>
        <nav>
            <span class="svg"><img src="img/svg.svg"></span>
            <div>
                <button class="btn ">English</button>
                <button class="btn btn-red"><a href="log.php" class="Contact">sign up</a></button>
            </div>
        </nav>
        <div class="center">
            <span>Laughter. Tears. Thrills. Find it all on Netflix.</span>
            <span>Unlimited movies, TV shows and more</span>
            <span>Ready to watch? Enter your email to create or restart your membership</span>
            <div class="input">
            <form method="post" class="form">
                <input type="text" class="ip" name="email" placeholder="email address">
                <input class="bt btn-red" type="submit" value="get started">        </form>
            </div>
        </div>
        <div class="line"></div>
        <section class="first">
            <div>
                <span>Enjoy on your TV</span>
                <span>Watch on smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players and more.</span>
            </div>
            <div class="sec-img">
                <img src="img/sec.png">
                <video autoplay muted loop
                    src="video/video-tv-in-0819.m4v"></video>
            </div>
        </section>
        <div class="line"></div>
        <section class="first secend">

            <div class="sec-img ">
                <img src="img/thir.jpg">

            </div>
            <div>
                <span>Download your shows to watch offline</span>
                <span>Save your favourites easily and always have something to watch.</span>
            </div>
        </section>
        <div class="line"></div>
        <section class="first thir">
            <div>
                <span>Watch everywhere</span>
                <span> Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV.</span>
            </div>
            <div class="sec-img thir-img">
                <img src="img/four.png">
                <video class="video" autoplay muted loop src="video/video-devices-in.m4v"></video>
            </div>
        </section>
        <div class="line"></div>
        <section class="first secend">
            <div class="sec-img ">
                <img src="img/five.png">

            </div>
            <div>
                <span>Create profiles for kids</span>
                <span>Send children on adventures with their favourite characters in a space made just for them—free
                    with your membership</span>
            </div>
        </section>
        <div class="line"></div>
        <div class="faq">
            <h3>Frequently Asked Questions</h3>
            <div class="faqbox a1">
                <span>what is netflix ?</span>
            </div>
            <div><span class="faqbox none d1 d11 d111"></span></div>
            <div class="faqbox a2">
                <span>How much does Netflix cost?</span>
            </div><span class="faqbox none d2 d12 d112"></span>
            <div class="faqbox a3">
                <span>Where can I watch?</span>
            </div><span class="faqbox none d3 d13 d113"></span>
            <div class="faqbox a4">
                <span>How do I cancel?</span>
            </div><span class="faqbox none d4 d14 d114"></span>
            <div class="faqbox a5">
                <span>What can I watch on Netflix?</span>
            </div><span class="faqbox none d5 d15 d115"></span>
           

        </div>
        <div class="line"></div>
        <div class="ques">
            <span>Questions? Call 000-800-919-1694</span>
            <div class="footer">
                <div class="items">
                    <span><a href="https://help.netflix.com/en/node/412" class="a"> FAQ</a></span>
                    <span><a href="https://help.netflix.com/en/">help center</a></span>
                    <span><a href="https://devices.netflix.com/en/"> ways to watch</a></span>
                    <span><a href="https://help.netflix.com/legal/privacy">privacy</a></span>
                </div>

                <div class="items">
                    <span> <a href="https://help.netflix.com/legal/notices">legal note</a></span>
                    <span><a href="https://media.netflix.com/en/">media center</a></span>
                    <span><a href="contact.html" class="Contact">contact us</a></span>
                    <span><a href="https://www.netflix.com/in/browse/genre/839338" class="Contact">Netflix Originals</a></span>
                </div>


                <div class="items no">
                    <span><a href="https://fast.com/" class="Contact">speed test</a></span>
                    <span><a href="https://help.netflix.com/legal/termsofuse/" class="Contact">terms of use</a></span>
                    <span><a href="https://jobs.netflix.com/" class="Contact">job</a></span>
                    <span>Netflix india</span>
                </div>


            </div>
        </div>
        <div class="footer1">
            <p>Designed with <svg xmlns="http://www.w3.org/2000/svg" height="20" width="20" viewBox="0 0 512 512"><path fill="#e80202" d="M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"/></svg>  by sanchit & suraj  ||  @copyright under 2024 --&#8669  netflix-clone  || project </p>
        </div>
        <br><br>
    
        <script>
            document.querySelector(".a1").addEventListener("click", () => {
                document.querySelector(".d1").style.display = "block";
                document.querySelector(".d11").innerHTML = "Netflix is a streaming service that offers a wide variety of award-winning TV shows, movies, anime, documentaries and more – on thousands of internet-connected devices.<br>You can watch as much as you want, whenever you want, without a single ad – all for one low monthly price. There's always something new to discover, and new TV shows and movies are added every week!";
            })

            document.querySelector(".a1").addEventListener("dblclick", () => {
                document.querySelector(".d111").style.display = "none";})

                document.querySelector(".a2").addEventListener("click", () => {
                document.querySelector(".d2").style.display = "block";
                document.querySelector(".d12").innerHTML = "Watch Netflix on your smartphone, tablet, Smart TV, laptop, or streaming device, all for one fixed monthly fee. Plans range from ₹649 to ₹149 a month. No extra costs, no contracts.";
            })

            document.querySelector(".a2").addEventListener("dblclick", () => {
                document.querySelector(".d112").style.display = "none";})

                document.querySelector(".a3").addEventListener("click", () => {
                document.querySelector(".d3").style.display = "block";
                document.querySelector(".d13").innerHTML = "Watch anywhere, anytime. Sign in with your Netflix account to watch instantly on the web at netflix.com from your personal computer or on any internet-connected device that offers the Netflix app, including smart TVs, smartphones, tablets, streaming media players and game consoles.";
            })

            document.querySelector(".a3").addEventListener("dblclick", () => {
                document.querySelector(".d113").style.display = "none";})

                document.querySelector(".a4").addEventListener("click", () => {
                document.querySelector(".d4").style.display = "block";
                document.querySelector(".d14").innerHTML = "Netflix is flexible. There are no annoying contracts and no commitments. You can easily cancel your account online in two clicks. There are no cancellation fees – start or stop your account anytime..";
            })

            document.querySelector(".a4").addEventListener("dblclick", () => {
                document.querySelector(".d114").style.display = "none";})

                document.querySelector(".a5").addEventListener("click", () => {
                document.querySelector(".d5").style.display = "block";
                document.querySelector(".d15").innerHTML = "Netflix has an extensive library of feature films, documentaries, TV shows, anime, award-winning Netflix originals, and more. Watch as much as you want, anytime you want";
            })

            document.querySelector(".a5").addEventListener("dblclick", () => {
                document.querySelector(".d115").style.display = "none";})
           
        </script>
</body>

</html>