<?php
session_start();
 $ee=$_SESSION['email'];
include("db.php");
$query="select * from logdata where  `email` = '$ee'";
$result=mysqli_query($con,$query);
         if($result && mysqli_num_rows($result)>0){
            $u2=mysqli_fetch_assoc($result);
            $username=$u2['username'];
            $email=$u2['email'];
            $phone=$u2['phone'];
         }

?>