<?php
$con=mysqli_connect("localhost","root","","log");
if(!$con){die("error!!!");}
?>